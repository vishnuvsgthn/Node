import React from 'react'

export const FileUpload = () => {
  return <div></div>
}
