import ReactDOM from "react-dom";

import React from "react";
import styled from "styled-components";

const HomeStyles = styled.div`
  display: flex;
  flex-direction: column;
  justify-items: center;
  align-items: center;

  h1 {
    font-size: 1.5em;
    text-align: center;
    color: royalblue;
  }

  button {
    width: 10rem;
    font-size: 1em;
    margin: 1em;
    padding: 0.25em 1em;
    border: 2px solid royalblue;
    border-radius: 3px;
    color: royalblue;
  }
`;

const ButtonsWrapper = styled.div`
  display: flex;
  justify-items: center;
  align-items: center;
`;

export default function Home() {
  return (
    <HomeStyles>
      <h1>Visual Inspection</h1>
      <ButtonsWrapper>
        <button>Capture</button>
        <label>
          <input type="checkbox" />
          Required
        </label>
      </ButtonsWrapper>
      <ButtonsWrapper>
        <button>Inspection</button>
        <label>
          <input type="checkbox" />
          Required
        </label>
      </ButtonsWrapper>
    </HomeStyles>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    <Home />
  </React.StrictMode>,
  rootElement
);
